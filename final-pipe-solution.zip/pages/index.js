
export default function Home() {
  return (
    <div>
      <h1>Welcome to Current and Pipe Solution</h1>
      <p>Electrical and Plumbing Services in Idappadi</p>
    </div>
  );
}
